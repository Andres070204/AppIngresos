package co.edu.unipiloto.ingreso;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.util.Log;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import com.google.firebase.auth.UserProfileChangeRequest;
import androidx.fragment.app.Fragment;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.AuthCredential;
import com.google.firebase.auth.EmailAuthProvider;
import android.widget.TextView;

public class PerfilConfig extends Fragment {
    private static final String TAG = "PerfilConfig";
    private EditText editTextUsername;
    private EditText editTextEmail;
    private EditText editTextNewPassword;
    private EditText editTextCurrentPassword;
    private Button buttonEditUsername;
    private Button buttonEditEmail;
    private Button buttonChangePassword;
    private TextView textViewUsername;
    private TextView textViewEmail;

    private FirebaseAuth mAuth;
    private FirebaseUser currentUser;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_perfil, container, false);

        // Inicializar FirebaseAuth
        mAuth = FirebaseAuth.getInstance();
        currentUser = mAuth.getCurrentUser();


        // Vistas
        //editTextUsername = view.findViewById(R.id.edit_text_username);
        //editTextEmail = view.findViewById(R.id.edit_text_email);
        editTextNewPassword = view.findViewById(R.id.edit_text_new_password);
        editTextCurrentPassword = view.findViewById(R.id.edit_text_current_password);
        buttonEditUsername = view.findViewById(R.id.button_edit_username);
        buttonEditEmail = view.findViewById(R.id.button_edit_email);
        buttonChangePassword = view.findViewById(R.id.button_change_password);
        textViewUsername = view.findViewById(R.id.text_username);
        textViewEmail = view.findViewById(R.id.text_email);

        // Mostrar información del usuario actual
        if (currentUser != null) {
            if (currentUser.getDisplayName() != null) {
                textViewUsername.setText(currentUser.getDisplayName());
            }
            if (currentUser.getEmail() != null) {
                textViewEmail.setText(currentUser.getEmail());
            }
        }

        // Botón para editar el nombre de usuario
        buttonEditUsername.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String newUsername = editTextUsername.getText().toString().trim();
                updateUsername(newUsername);
            }
        });

        // Botón para editar el correo electrónico
        buttonEditEmail.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String newEmail = editTextEmail.getText().toString().trim();
                updateEmail(newEmail);
            }
        });

        // Botón para cambiar la contraseña

        buttonChangePassword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d(TAG, "Botón de cambio de contraseña clickeado");
                String newPassword = editTextNewPassword.getText().toString().trim();
                String currentPassword = editTextCurrentPassword.getText().toString().trim();
                changePassword(currentPassword, newPassword);
            }
        });

        return view;
    }

    // Método para actualizar el nombre de usuario
    private void updateUsername(String newUsername) {
        currentUser.updateProfile(new UserProfileChangeRequest.Builder()
                        .setDisplayName(newUsername)
                        .build())
                .addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        if (task.isSuccessful()) {
                            textViewUsername.setText(newUsername);
                        }
                    }
                });
    }

    // Método para actualizar el correo electrónico
    private void updateEmail(String newEmail) {
        currentUser.updateEmail(newEmail)
                .addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        if (task.isSuccessful()) {
                            textViewEmail.setText(newEmail);
                        }
                    }
                });
    }

    // Método para cambiar la contraseña
    private void changePassword(String currentPassword, String newPassword) {
        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        if (user != null) {
            // Reautenticar al usuario
            AuthCredential credential = EmailAuthProvider.getCredential(user.getEmail(), currentPassword);
            user.reauthenticate(credential)
                    .addOnCompleteListener(new OnCompleteListener<Void>() {
                        @Override
                        public void onComplete(@NonNull Task<Void> task) {
                            if (task.isSuccessful()) {
                                // Reautenticación exitosa, cambiar la contraseña
                                user.updatePassword(newPassword)
                                        .addOnCompleteListener(new OnCompleteListener<Void>() {
                                            @Override
                                            public void onComplete(@NonNull Task<Void> task) {
                                                if (task.isSuccessful()) {
                                                    // Contraseña cambiada exitosamente
                                                    Log.d(TAG, "Contraseña cambiada exitosamente");
                                                } else {
                                                    // Error al cambiar la contraseña
                                                    Log.w(TAG, "Error al cambiar la contraseña", task.getException());
                                                }
                                            }
                                        });
                            } else {
                                // Error al reautenticar al usuario
                                Log.w(TAG, "Error al reautenticar al usuario", task.getException());
                            }
                        }
                    });
        } else {
            Log.w(TAG, "El usuario no está autenticado");
        }
    }




}